<!--
end content
__________________________________________________________________
-->
<hr />
<!--
begin footer
__________________________________________________________________
-->
<div id="footer">
	<p id="address">
		<span>Buhr Construction</span> 
		<span>1290 County Road DK, Brussels, WI 54204</span>
<span>T: 920-825-1318 F: 920-825-7761</span><a href="mailto:info@buhrconstruction.com">info@buhrconstruction.com</span></a></p>
</div>
<!--
end footer
__________________________________________________________________
-->
</body>
</html>