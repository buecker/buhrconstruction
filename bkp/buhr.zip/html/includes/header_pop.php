<!DOCTYPE html 
	PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html 
	xmlns="http://www.w3.org/1999/xhtml"
	xml:lang="en" lang="en">
<head>
<title>Buhr Construction</title>
<meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>
<base href="http://www.buhrconstruction.com/" />
<style type="text/css">@import url("css/base.css");</style>
<style type="text/css">
<!--
	body { background: none; }
	div#content { 
		margin: 10px 20px;
		padding: 0; }
	div#shinglemaster_cert { font-size: 14px; }
-->
</style>
</head>
<body>
<hr />
<!--
begin content
__________________________________________________________________
-->
