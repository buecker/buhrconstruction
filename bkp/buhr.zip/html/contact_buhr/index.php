<?php include "{$_SERVER['DOCUMENT_ROOT']}/includes/header.php" ?>
<div id="content">
	<h2 id="contact_buhr"><span>Contact Buhr Construction</span></h2>
	<div id="content_col">
	
		<form action="http://www.buhrconstruction.com/contact_buhr/formmail.php" method="post">
			<div class="form_item">
				<p>Name</p>
				<div><input type="text" name="Contact name" /></div>
			</div>
	
			<div class="form_item">
				<p>Address</p>
				<div><input type="text" name="Address" /></div>
				<div><input type="text" name="Address, Line 2" /> <span class="smalltext">(optional)</span></div>
			</div>
		
			<div class="form_item">
				<div class="h">
					<p>City</p>
					<div><input type="text" name="City" /></div>
				</div>
				<div class="h">
					<p>State</p>
					<div><input id="state" type="text" name="State" maxlength="2" /></div>
				</div>
				<div class="h">
					<p>Zip code</p>
					<div><input id="zip" type="text" name="Zip code" maxlength="5" /></div>
				</div>
			</div>
	
			<div class="form_item">
				<p>Daytime phone number</p>
				<div><input type="text" name="Phone number" /></div>
			</div>
			<div class="form_item">
				<p>Evening phone number</p>
				<div><input type="text" name="Phone number" /></div>
			</div>
			<div class="form_item">
				<p>Cellphone number</p>
				<div><input type="text" name="Phone number" /></div>
			</div>
	
			<div class="form_item">
				<p>Fax number</p>
				<div><input type="text" name="Fax number" /></div>
			</div>
	
			<div class="form_item">
				<p>E-mail address</p>
				<div><input type="text" name="E-mail address" /></div>
			</div>
	
			<div class="form_item">
				<p>How did you hear about Buhr Construction?</p>
				<div><textarea name="Referral source" cols="40" rows="2"></textarea></div>			
			</div>
			<div class="form_item">
				<p>How would you prefer to be contacted by Buhr Construction? (please check all that apply.)</p>
				<div>
					<span><input type="checkbox" name="Preferred Contact:" value="E-mail" checked /> E-mail</span>
					<span><input type="checkbox" name="Preferred Contact:" value="Daytime Phone" /> Daytime Phone</span>
					<span><input type="checkbox" name="Preferred Contact:" value="Evening Phone" /> Evening Phone</span><br />
					<span><input type="checkbox" name="Preferred Contact:" value="Cell Phone" /> Cell Phone</span>
					<span><input type="checkbox" name="Preferred Contact:" value="Fax" /> Fax</span>
					<span><input type="checkbox" name="Preferred Contact:" value="Postal Mail" /> Postal Mail</span>
				</div>			
			</div>
			
			<div class="form_item">
				<p>Comments or questions</p>
				<div><textarea name="Comments or questions" cols="40" rows="8"></textarea></div>
			</div>
			
			<div><input type="submit" value="Send Comments" /></div>

		</form>
	</div>
</div>
<?php include "{$_SERVER['DOCUMENT_ROOT']}/includes/footer.php" ?>
