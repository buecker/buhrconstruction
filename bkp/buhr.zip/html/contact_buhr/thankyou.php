<?php include "{$_SERVER['DOCUMENT_ROOT']}/includes/header.php" ?>
<div id="content">
	<h2 id="contact_buhr"><span>Contact Buhr Construction</span></h2>
	<div id="content_col">
		<h3>Thank you!</h3>
		<p>Your message has been sent to Buhr Construction.</p>
	</div>
</div>
<?php include "{$_SERVER['DOCUMENT_ROOT']}/includes/footer.php" ?>