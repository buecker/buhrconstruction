
<csscriptdict import>
	<script type="text/javascript" src="../GeneratedItems/CSScriptLib.js"></script>
</csscriptdict>
<csactiondict>
	<script type="text/javascript"><!--
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_1_button',/*URL*/'../images/gallery_images/home_1sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_2',/*URL*/'../images/gallery_images/home_2sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_3',/*URL*/'../images/gallery_images/home_3sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_4',/*URL*/'../images/gallery_images/home_4sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_1',/*URL*/'../images/gallery_images/barn_1sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_3',/*URL*/'../images/gallery_images/barn_3sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_4',/*URL*/'../images/gallery_images/barn_4sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_2',/*URL*/'../images/gallery_images/barn_2sm.jpg',/*URL*/'',/*URL*/'','');
CSAct[/*CMP*/ 'BD82EBC88'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/newhome_1.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC029'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/newhome_2.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC2310'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/newhome_3.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC5211'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/newhome_4.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC7012'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/barn_1.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD86DCB13'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/barn_1.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD86DCB35'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/barn_1.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD86DCB57'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/barn_2.html','',650,600,true,true,false,false,false,false,false);

// --></script>
</csactiondict>

<csscriptdict import>
	<script type="text/javascript" src="../GeneratedItems/CSScriptLib.js"></script>
</csscriptdict>
<csactiondict>
	<script type="text/javascript"><!--
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_1_button',/*URL*/'../images/gallery_images/home_1sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_2',/*URL*/'../images/gallery_images/home_2sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_3',/*URL*/'../images/gallery_images/home_3sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_4',/*URL*/'../images/gallery_images/home_4sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_1',/*URL*/'../images/gallery_images/barn_1sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_2',/*URL*/'../images/gallery_images/barn_2sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_3',/*URL*/'../images/gallery_images/barn_3sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_4',/*URL*/'../images/gallery_images/barn_4sm.jpg',/*URL*/'',/*URL*/'','');
CSAct[/*CMP*/ 'BD82EBC88'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/newhome_1.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC029'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/newhome_2.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC2310'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/newhome_3.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC5211'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/newhome_4.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC7012'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/barn_1.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC8913'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/barn_2.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82ECAB14'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/barn_3.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82ECCB15'] = new Array(CSOpenWindow,/*URL*/ '../images/gallery_images/barn_4.html','',650,600,true,true,false,false,false,false,false);

// --></script>
</csactiondict>

<csscriptdict import>
	<script type="text/javascript" src="../GeneratedItems/CSScriptLib.js"></script>
</csscriptdict>
<csactiondict>
	<script type="text/javascript"><!--
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_1',/*URL*/'../images/gallery_images/home_1sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_2',/*URL*/'../images/gallery_images/home_2sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_3',/*URL*/'../images/gallery_images/home_3sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_4',/*URL*/'../images/gallery_images/home_4sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_1',/*URL*/'../images/gallery_images/barn_1sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_2',/*URL*/'../images/gallery_images/barn_2sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_3',/*URL*/'../images/gallery_images/barn_3sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_4',/*URL*/'../images/gallery_images/barn_4sm.jpg',/*URL*/'',/*URL*/'','');
CSAct[/*CMP*/ 'BD82EBC88'] = new Array(CSOpenWindow,/*URL*/ 'newhome_1.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC029'] = new Array(CSOpenWindow,/*URL*/ 'newhome_2.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC2310'] = new Array(CSOpenWindow,/*URL*/ 'newhome_3.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC5211'] = new Array(CSOpenWindow,/*URL*/ 'newhome_4.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC7012'] = new Array(CSOpenWindow,/*URL*/ 'barn_1.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC8913'] = new Array(CSOpenWindow,/*URL*/ 'barn_2.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82ECAB14'] = new Array(CSOpenWindow,/*URL*/ 'barn_3.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82ECCB15'] = new Array(CSOpenWindow,/*URL*/ 'barn_4.html','',650,600,true,true,false,false,false,false,false);

// --></script>
</csactiondict>

<csscriptdict import>
	<script type="text/javascript" src="../GeneratedItems/CSScriptLib.js"></script>
</csscriptdict>
<csactiondict>
	<script type="text/javascript"><!--
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_1',/*URL*/'../images/gallery_images/home_1sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_2',/*URL*/'../images/gallery_images/home_2sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_3',/*URL*/'../images/gallery_images/home_3sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_4',/*URL*/'../images/gallery_images/home_4sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_1',/*URL*/'../images/gallery_images/barn_1sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_2',/*URL*/'../images/gallery_images/barn_2sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_3',/*URL*/'../images/gallery_images/barn_3sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_4',/*URL*/'../images/gallery_images/barn_4sm.jpg',/*URL*/'',/*URL*/'','');
CSAct[/*CMP*/ 'BD82EBC88'] = new Array(CSOpenWindow,/*URL*/ 'newhome_1.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC029'] = new Array(CSOpenWindow,/*URL*/ 'newhome_2.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC2310'] = new Array(CSOpenWindow,/*URL*/ 'newhome_3.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC5211'] = new Array(CSOpenWindow,/*URL*/ 'newhome_4.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC7012'] = new Array(CSOpenWindow,/*URL*/ 'barn_1.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82EC8913'] = new Array(CSOpenWindow,/*URL*/ 'barn_2.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82ECAB14'] = new Array(CSOpenWindow,/*URL*/ 'barn_3.html','',650,600,true,true,false,false,false,false,false);
CSAct[/*CMP*/ 'BD82ECCB15'] = new Array(CSOpenWindow,/*URL*/ 'barn_4.html','',650,600,true,true,false,false,false,false,false);

// --></script>
</csactiondict>

<csscriptdict import>
	<script type="text/javascript" src="../GeneratedItems/CSScriptLib.js"></script>
</csscriptdict>
<csactiondict>
	<script type="text/javascript"><!--
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_1',/*URL*/'../images/gallery_images/home_1sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_2',/*URL*/'../images/gallery_images/home_2sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_3',/*URL*/'../images/gallery_images/home_3sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'home_4',/*URL*/'../images/gallery_images/home_4sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_1',/*URL*/'../images/gallery_images/barn_1sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_2',/*URL*/'../images/gallery_images/barn_2sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_3',/*URL*/'../images/gallery_images/barn_3sm.jpg',/*URL*/'',/*URL*/'','');
CSInit[CSInit.length] = new Array(CSILoad,/*CMP*/'barn_4',/*URL*/'../images/gallery_images/barn_4sm.jpg',/*URL*/'',/*URL*/'','');
CSAct[/*CMP*/ 'BD82E9A80'] = new Array(CSSetImageURL,/*CMP*/ 'home_1',/*URL*/ 'newhome_1.html');
CSAct[/*CMP*/ 'BD82E9CD1'] = new Array(CSSetImageURL,/*CMP*/ 'home_2',/*URL*/ 'newhome_2.html');
CSAct[/*CMP*/ 'BD82E9E52'] = new Array(CSSetImageURL,/*CMP*/ 'home_3',/*URL*/ 'newhome_3.html');
CSAct[/*CMP*/ 'BD82E9FE3'] = new Array(CSSetImageURL,/*CMP*/ 'home_4',/*URL*/ 'newhome_4.html');
CSAct[/*CMP*/ 'BD82EA1C4'] = new Array(CSSetImageURL,/*CMP*/ 'barn_1',/*URL*/ 'barn_1.html');
CSAct[/*CMP*/ 'BD82EA305'] = new Array(CSSetImageURL,/*CMP*/ 'barn_2',/*URL*/ 'barn_2.html');
CSAct[/*CMP*/ 'BD82EA406'] = new Array(CSSetImageURL,/*CMP*/ 'barn_3',/*URL*/ 'barn_3.html');
CSAct[/*CMP*/ 'BD82EA5A7'] = new Array(CSSetImageURL,/*CMP*/ 'barn_4',/*URL*/ 'barn_4.html');

// --></script>
</csactiondict>
<csactions>
		<csaction name="BD82EBC88" class="Open Window" type="onevent" val0="../images/gallery_images/newhome_1.html" val1="" val2="650" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="false" urlparams="1"></csaction>
		<csaction name="BD82EC029" class="Open Window" type="onevent" val0="../images/gallery_images/newhome_2.html" val1="" val2="650" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="false" urlparams="1"></csaction>
		<csaction name="BD82EC2310" class="Open Window" type="onevent" val0="../images/gallery_images/newhome_3.html" val1="" val2="650" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="false" urlparams="1"></csaction>
		<csaction name="BD82EC5211" class="Open Window" type="onevent" val0="../images/gallery_images/newhome_4.html" val1="" val2="650" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="false" urlparams="1"></csaction>
		<csaction name="BD82EC7012" class="Open Window" type="onevent" val0="../images/gallery_images/barn_1.html" val1="" val2="650" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="false" urlparams="1"></csaction>
		<csaction name="BD86DCB13" class="Open Window" type="onevent" val0="../images/gallery_images/barn_1.html" val1="" val2="650" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="false" urlparams="1"></csaction>
		<csaction name="BD86DCB35" class="Open Window" type="onevent" val0="../images/gallery_images/barn_1.html" val1="" val2="650" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="false" urlparams="1"></csaction>
		<csaction name="BD86DCB57" class="Open Window" type="onevent" val0="../images/gallery_images/barn_2.html" val1="" val2="650" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="false" urlparams="1"></csaction>
	</csactions>
<?php include "{$_SERVER['DOCUMENT_ROOT']}/includes/header.php" ?>
	<div id="content">
	<div id="testimonial_col">
		<div id="testimonial_01" class="testimonial">
				<p>We would like to express our gratitude for the quality workmanship that went into building our home. Because this home is the biggest investment we have ever made, it is very assuring to know the house is built well. Other subs have even commented on how square everything is and how well built the house is. We have and will continue to share our positive comments and recommendations with friends and anyone else looking to have a quality home built for them. Thank you Buhr Construction for helping to make our building experience a positive one.</p>
				<p>Cory & Tara Pierre</p>
			</div>
	</div>
	<div id="content_col">
			<table width="188" border="0" cellspacing="5" cellpadding="0">
				<tr>
					<td colspan="4">Click on the image to view a full size photo. <br>
						<p>Scroll through the gallery by clicking on Next or Back.<br>
							<br>
							<br>
							New Home Construction</p>
					</td>
				</tr>
				<tr>
					<td><csobj al="" csclick="BD82EBC88" h="100" t="Button" w="100"><a href="../images/gallery_images/newhome_1.html" target="_blank" onmouseover="return CSIShow(/*CMP*/'home_1_button',1)" onmouseout="return CSIShow(/*CMP*/'home_1_button',0)" onclick="CSAction(new Array(/*CMP*/'BD82EBC88'));return CSClickReturn()"><img src="../images/gallery_images/home_1sm.jpg" width="100" height="100" name="home_1_button" border="0" alt=""></a></csobj></td>
					<td><csobj al="" csclick="BD82EC029" h="100" t="Button" w="100"><a href="../images/gallery_images/newhome_2.html" target="_blank" onmouseover="return CSIShow(/*CMP*/'home_2',1)" onmouseout="return CSIShow(/*CMP*/'home_2',0)" onclick="CSAction(new Array(/*CMP*/'BD82EC029'));return CSClickReturn()"><img src="../images/gallery_images/home_2sm.jpg" width="100" height="100" name="home_2" border="0" alt=""></a></csobj></td>
					<td><csobj al="" csclick="BD82EC2310" h="100" t="Button" w="100"><a href="../images/gallery_images/newhome_3.html" target="_blank" onmouseover="return CSIShow(/*CMP*/'home_3',1)" onmouseout="return CSIShow(/*CMP*/'home_3',0)" onclick="CSAction(new Array(/*CMP*/'BD82EC2310'));return CSClickReturn()"><img src="../images/gallery_images/home_3sm.jpg" width="100" height="100" name="home_3" border="0" alt=""></a></csobj></td>
					<td><csobj al="" csclick="BD82EC5211" h="100" t="Button" w="100"><a href="../images/gallery_images/newhome_4.html" target="_blank" onmouseover="return CSIShow(/*CMP*/'home_4',1)" onmouseout="return CSIShow(/*CMP*/'home_4',0)" onclick="CSAction(new Array(/*CMP*/'BD82EC5211'));return CSClickReturn()"><img src="../images/gallery_images/home_4sm.jpg" width="100" height="100" name="home_4" border="0" alt=""></a></csobj></td>
				</tr>
				<tr>
					<td colspan="4"><br>
						Barn Remodeling - Before | During | After</td>
				</tr>
				<tr>
					<td><csobj al="" csclick="BD82EC7012" h="100" t="Button" w="100"><a href="../images/gallery_images/barn_1.html" target="_blank" onmouseover="return CSIShow(/*CMP*/'barn_1',1)" onmouseout="return CSIShow(/*CMP*/'barn_1',0)" onclick="CSAction(new Array(/*CMP*/'BD82EC7012'));return CSClickReturn()"><img src="../images/gallery_images/barn_1sm.jpg" width="100" height="100" name="barn_1" border="0" alt=""></a></csobj></td>
					<td><csobj al="" csclick="BD86DCB13" h="100" t="Button" w="100"><a href="../images/gallery_images/barn_1.html" target="_blank" onmouseover="return CSIShow(/*CMP*/'barn_3',1)" onmouseout="return CSIShow(/*CMP*/'barn_3',0)" onclick="CSAction(new Array(/*CMP*/'BD86DCB13'));return CSClickReturn()"><img src="../images/gallery_images/barn_3sm.jpg" width="100" height="100" name="barn_3" border="0" alt=""></a></csobj></td>
					<td><csobj al="" csclick="BD86DCB35" h="100" t="Button" w="100"><a href="../images/gallery_images/barn_1.html" target="_blank" onmouseover="return CSIShow(/*CMP*/'barn_4',1)" onmouseout="return CSIShow(/*CMP*/'barn_4',0)" onclick="CSAction(new Array(/*CMP*/'BD86DCB35'));return CSClickReturn()"><img src="../images/gallery_images/barn_4sm.jpg" width="100" height="100" name="barn_4" border="0" alt=""></a></csobj></td>
					<td><csobj al="" csclick="BD86DCB57" h="100" t="Button" w="100"><a href="../images/gallery_images/barn_2.html" target="_blank" onmouseover="return CSIShow(/*CMP*/'barn_2',1)" onmouseout="return CSIShow(/*CMP*/'barn_2',0)" onclick="CSAction(new Array(/*CMP*/'BD86DCB57'));return CSClickReturn()"><img src="../images/gallery_images/barn_2sm.jpg" width="100" height="100" name="barn_2" border="0" alt=""></a></csobj></td>
				</tr>
			</table>
			<p></p>
		</div>
</div>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<?php include "{$_SERVER['DOCUMENT_ROOT']}/includes/footer.php" ?>
</body></body>
